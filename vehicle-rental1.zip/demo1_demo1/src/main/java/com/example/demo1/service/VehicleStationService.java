package com.example.demo1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo1.model.VehicleStation;
import com.example.demo1.repository.VehicleStationRepository;

@Service
public class VehicleStationService {
	@Autowired
    private VehicleStationRepository vehicleStationRepository;

    public VehicleStation createVehicleStation(VehicleStation vehicleStation) {
        return vehicleStationRepository.save(vehicleStation);
    }

    public List<VehicleStation> getAllVehicleStations() {
        return vehicleStationRepository.findAll();
    }

}
