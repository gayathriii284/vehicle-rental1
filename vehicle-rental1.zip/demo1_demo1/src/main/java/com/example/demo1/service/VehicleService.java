package com.example.demo1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo1.model.Vehicle;
import com.example.demo1.repository.VehicleRepository;

@Service
public class VehicleService {
	 @Autowired
	 private VehicleRepository vehicleRepository;

	 public List<Vehicle> getVehiclesByVehicleStationId(Long vehicleStationId) {
		 return vehicleRepository.findByVehicleStationId(vehicleStationId);
	 }

	 public Vehicle addVehicleToInventory(Vehicle vehicle) {
		 return vehicleRepository.save(vehicle);
	   }
}
