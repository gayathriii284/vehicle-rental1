package com.example.demo1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.model.VehicleStation;
import com.example.demo1.service.VehicleStationService;

@RestController
@RequestMapping("/vehicle-stations")
public class VehicleStationController {
    @Autowired
    private VehicleStationService vehicleStationService;

    @GetMapping("/getStation")
    public ResponseEntity<List<VehicleStation>> getAllVehicleStations() {
        List<VehicleStation> vehicleStations = vehicleStationService.getAllVehicleStations();
        if (vehicleStations.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(vehicleStations, HttpStatus.OK);
    }

    @PostMapping("/createVehicle")
    public ResponseEntity<VehicleStation> createVehicleStation(@RequestBody VehicleStation vehicleStation) {
        VehicleStation createdVehicleStation = vehicleStationService.createVehicleStation(vehicleStation);
        return new ResponseEntity<>(createdVehicleStation, HttpStatus.CREATED);
    }
}
