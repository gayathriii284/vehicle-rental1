package com.example.demo1.service;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo1.model.User;
import com.example.demo1.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	public User registerUser(User user) {
		Optional<User> existingUser=userRepository.findByPhone(user.getPhone());
		if (existingUser.isPresent()) {
			throw new IllegalArgumentException("User already exists");
		}
		
		//generate OTP
		String otp=generateOtp();
		user.setOtp(otp);
		
		// save user to the database with the generated OTP
		return userRepository.save(user);
	}
	
	private String generateOtp() {
		return String.format("%06d", new Random().nextInt(999999));
	}
}
